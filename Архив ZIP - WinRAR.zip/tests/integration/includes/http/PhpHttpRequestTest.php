<?php

/**
 * @group large
 * @covers PhpHttpRequest
 */
class PhpHttpRequestTest extends MWHttpRequestTestCase {
	protected static $httpEngine = 'php';
}
