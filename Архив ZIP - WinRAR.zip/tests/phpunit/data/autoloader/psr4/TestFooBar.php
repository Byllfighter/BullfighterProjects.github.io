<?php

namespace Test\MediaWiki\AutoLoader;

class TestFooBar {
}
