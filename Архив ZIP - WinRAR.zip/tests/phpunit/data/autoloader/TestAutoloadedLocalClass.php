<?php

class TestAutoloadedLocalClass {
}
