/* eslint-disable */
mw.foo()
